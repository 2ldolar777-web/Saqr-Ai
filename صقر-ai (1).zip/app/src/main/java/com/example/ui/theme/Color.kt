package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBg = Color(0xFF070707)
val CyberBgGradientStart = Color(0xFF0A0E27)
val CyberBgGradientEnd = Color(0xFF1A1F3A)

val CyberSurface = Color(0xFF1A1A2E)
val CyberCard = Color(0xFF16213E)

val CyberCyan = Color(0xFF00D4FF)
val CyberCyanDim = Color(0x3300D4FF)
val CyberBlue = Color(0xFF0099CC)

val CyberPink = Color(0xFFFF0055)
val CyberPinkDim = Color(0x33FF0055)

val CyberText = Color(0xFFE0E0E0)
val CyberTextMuted = Color(0xFF888888)
val CyberGreen = Color(0xFF00FF88)
