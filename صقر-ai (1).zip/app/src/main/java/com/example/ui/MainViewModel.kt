package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AiModel
import com.example.data.model.ChatMessage
import com.example.engine.TaskEngine
import com.example.manager.SystemSettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val taskEngine = TaskEngine(context)
    private val settingsManager = SystemSettingsManager(context)

    // قائمة النماذج المحلية المتاحة للتنزيل والتبديل
    private val _models = MutableStateFlow(
        listOf(
            AiModel(
                id = "phi3",
                name = "Phi-3.5-mini-instruct",
                subtitle = "محرك محلي 4-bit سريع وهادئ موصى به لـ Redmi 14C",
                sizeGb = 2.4f,
                isDownloaded = true,
                isActive = true
            ),
            AiModel(
                id = "gemma",
                name = "Gemma-2B-Q4_K_M",
                subtitle = "نموذج خفيف من Google متوافق مع الحسابات الرياضية",
                sizeGb = 1.6f,
                isDownloaded = false,
                isActive = false
            ),
            AiModel(
                id = "llama3",
                name = "Llama-3-8B-Local",
                subtitle = "أداء تفكير متقدم للتعامل مع المهام المتعددة",
                sizeGb = 4.8f,
                isDownloaded = false,
                isActive = false
            ),
            AiModel(
                id = "saqr_ultra",
                name = "Saqr-Automator-v2.ONNX",
                subtitle = "نموذج مخصص مدمج لأوامر الهاتف والأتمتة السريعة",
                sizeGb = 0.8f,
                isDownloaded = true,
                isActive = false
            )
        )
    )
    val models = _models.asStateFlow()

    // قائمة رسائل الدردشة
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    // حالة النظام والإحصائيات
    private val _ramUsage = MutableStateFlow(2.4f)
    val ramUsage = _ramUsage.asStateFlow()

    private val _latency = MutableStateFlow(45)
    val latency = _latency.asStateFlow()

    private val _temperature = MutableStateFlow(38)
    val temperature = _temperature.asStateFlow()

    private val _battery = MutableStateFlow(85)
    val battery = _battery.asStateFlow()

    private val _aiStatus = MutableStateFlow("جاهز للعمل")
    val aiStatus = _aiStatus.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing = _isProcessing.asStateFlow()

    // فحص الصلاحيات والروت
    private val _hasSecurePermission = MutableStateFlow(false)
    val hasSecurePermission = _hasSecurePermission.asStateFlow()

    private val _hasRootAccess = MutableStateFlow(false)
    val hasRootAccess = _hasRootAccess.asStateFlow()

    init {
        // رسالة الترحيب المدمجة في شخصية الـ APK
        addMessage(
            text = "مرحباً! أنا صقر AI، وكيل الذكاء الصناعي المدمج في نظام هذا الهاتف (Offline-First). يمكنني تنفيذ أوامر التحكم بالهاتف فوراً أو توجيهها إلى Tasker. كيف أساعدك اليوم؟",
            isUser = false
        )
        refreshSystemStatus()
        startTelemetryLoop()
    }

    fun refreshSystemStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            _hasSecurePermission.value = settingsManager.hasWriteSecureSettingsPermission()
            _hasRootAccess.value = settingsManager.isRootAvailable()
        }
    }

    private fun startTelemetryLoop() {
        viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                delay(4000)
                // محاكاة حية لطاقة ومعالجة Redmi 14C
                val activeModel = _models.value.find { it.isActive }
                val baseRam = if (activeModel?.id == "llama3") 4.2f else 2.4f
                _ramUsage.value = baseRam + ((Math.random() * 0.4f).toFloat() - 0.2f)
                _latency.value = (35 + Math.random() * 25).toInt()
                _temperature.value = (36 + Math.random() * 4).toInt()
            }
        }
    }

    private fun addMessage(text: String, isUser: Boolean, isSystemAlert: Boolean = false) {
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        _messages.update { current ->
            current + ChatMessage(
                id = UUID.randomUUID().toString(),
                text = text,
                isUser = isUser,
                timestamp = timeFormat,
                isSystemAlert = isSystemAlert
            )
        }
    }

    /**
     * معالجة رسالة المستخدم الصوتية أو النصية وتشغيل أوامر النظام على Dispatchers.IO
     */
    fun sendUserCommand(input: String) {
        if (input.isBlank() || _isProcessing.value) return

        addMessage(input, isUser = true)
        _isProcessing.value = true
        _aiStatus.value = "جاري التحليل البرمجي..."

        viewModelScope.launch(Dispatchers.IO) {
            delay(400) // محاكاة استدلال النموذج المحلي

            // 1. التحقق هل هو أمر تنزيل نموذج أو تبديل
            if (handleModelCommands(input)) {
                _isProcessing.value = false
                _aiStatus.value = "جاهز للعمل"
                return@launch
            }

            // 2. تحليل أمر النظام عبر TaskEngine المركزية
            val report = taskEngine.analyzeAndExecuteComplexCommands(input)

            // 3. صياغة الرد بشخصية صقر المدمجة في الـ APK
            val responseText = buildString {
                append("▲ صقر AI: ")
                if (report.isSuccess) {
                    append("تم تنفيذ الأمر بنجاح.\n")
                    append("• الإجراء: ${report.actionDescription}\n")
                    append("• النتيجة: ${report.resultText}")
                } else {
                    append("لم يكتمل التنفيذ المباشر للأمر.\n")
                    append("• النتيجة: ${report.resultText}\n")
                }

                if (report.adviceText != null) {
                    append("\n\n💡 نصيحة المطور: ${report.adviceText}")
                }
            }

            addMessage(responseText, isUser = false, isSystemAlert = !report.isSuccess)
            _isProcessing.value = false
            _aiStatus.value = "نشط ومستقر"
        }
    }

    private fun handleModelCommands(input: String): Boolean {
        val lower = input.lowercase()
        if (lower.contains("تنزيل") || lower.contains("تحميل") || lower.contains("download")) {
            val target = _models.value.find { !it.isDownloaded }
            if (target != null) {
                downloadModel(target.id)
                addMessage("بدء تنزيل النموذج المتقدم: ${target.name} (${target.sizeGb} GB)... راقب قائمة التنزيلات في تبويب النماذج.", isUser = false)
                return true
            }
        }
        if (lower.contains("تبديل") || lower.contains("switch") || lower.contains("نموذج")) {
            val other = _models.value.find { it.isDownloaded && !it.isActive }
            if (other != null) {
                switchActiveModel(other.id)
                return true
            }
        }
        return false
    }

    /**
     * أمر تنزيل النموذج المحلي في الخلفية
     */
    fun downloadModel(modelId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _models.update { list ->
                list.map { if (it.id == modelId) it.copy(isDownloading = true, downloadProgress = 0.05f) else it }
            }

            var prog = 0.05f
            while (prog < 1.0f) {
                delay(250)
                prog += 0.08f
                val safeProg = prog.coerceAtMost(1f)
                _models.update { list ->
                    list.map { if (it.id == modelId) it.copy(downloadProgress = safeProg) else it }
                }
            }

            _models.update { list ->
                list.map { if (it.id == modelId) it.copy(isDownloading = false, isDownloaded = true, downloadProgress = 1f) else it }
            }
            addMessage("✔ اكتمل تنزيل وحفظ النموذج محلياً: ${_models.value.find { it.id == modelId }?.name}", isUser = false, isSystemAlert = true)
        }
    }

    /**
     * خيارات تبديل النموذج المحلي الفعلي
     */
    fun switchActiveModel(modelId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _isProcessing.value = true
            _aiStatus.value = "تبديل محرك الذكاء..."
            delay(600)

            _models.update { list ->
                list.map { it.copy(isActive = (it.id == modelId)) }
            }

            val newActive = _models.value.find { it.isActive }
            addMessage("⚡ تم التبديل بنجاح إلى المحرك المحلي: ${newActive?.name} (${newActive?.sizeGb} GB)", isUser = false)
            _isProcessing.value = false
            _aiStatus.value = "نشط (${newActive?.name})"
        }
    }

    /**
     * تنفيذ أمر مباشر للواي فاي أو البلوتوث من واجهة الأزرار السريعة
     */
    fun quickActionToggle(action: String) {
        sendUserCommand(action)
    }
}
