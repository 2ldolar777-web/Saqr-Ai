package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SaqrDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color.Black,
    primaryContainer = CyberSurface,
    onPrimaryContainer = CyberCyan,
    secondary = CyberBlue,
    onSecondary = Color.White,
    tertiary = CyberPink,
    onTertiary = Color.White,
    background = CyberBg,
    onBackground = CyberText,
    surface = CyberSurface,
    onSurface = CyberText,
    surfaceVariant = CyberCard,
    onSurfaceVariant = CyberTextMuted,
    error = CyberPink,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Force futuristic cyberpunk theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SaqrDarkColorScheme,
        typography = Typography,
        content = content
    )
}
