package com.example.service

import android.content.Context
import android.content.Intent
import android.util.Log

class TaskerIntegrationService(private val context: Context) {

    companion object {
        const val TASKER_ACTION_TASK = "net.dinglisch.android.tasker.ACTION_TASK"
        const val EXTRA_TASK_NAME = "task_name"
        const val EXTRA_VAR_NAMES = "varNames"
        const val EXTRA_VAR_VALUES = "varValues"
    }

    /**
     * إرسال أمر أتمتة عبر Intent Broadcast إلى Tasker أو تطبيقات الأتمتة الخارجية
     */
    fun sendAutomationTask(taskName: String, parameter: String? = null): Boolean {
        return try {
            val intent = Intent(TASKER_ACTION_TASK).apply {
                putExtra(EXTRA_TASK_NAME, taskName)
                if (parameter != null) {
                    putExtra(EXTRA_VAR_NAMES, arrayOf("%par1"))
                    putExtra(EXTRA_VAR_VALUES, arrayOf(parameter))
                }
                // ضمان وصول البث عبر النطاق العام للتطبيقات المستقبلة
                addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
            }
            context.sendBroadcast(intent)
            Log.d("TaskerIntegration", "تم توجيه الأمر: $taskName بالمعامل: $parameter إلى Tasker")
            true
        } catch (e: Exception) {
            Log.e("TaskerIntegration", "فشل توجيه البث لـ Tasker: ${e.localizedMessage}")
            false
        }
    }
}
