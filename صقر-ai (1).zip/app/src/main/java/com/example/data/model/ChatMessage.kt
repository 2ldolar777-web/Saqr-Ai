package com.example.data.model

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: String = "",
    val isSystemAlert: Boolean = false
)
