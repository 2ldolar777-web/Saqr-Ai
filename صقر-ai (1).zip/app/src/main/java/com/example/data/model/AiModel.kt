package com.example.data.model

data class AiModel(
    val id: String,
    val name: String,
    val subtitle: String,
    val sizeGb: Float,
    val isDownloaded: Boolean = false,
    val isDownloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val isActive: Boolean = false
)
