package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AiModel
import com.example.data.model.ChatMessage
import com.example.manager.SystemSettingsManager
import com.example.ui.MainViewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // فرض الاتجاه من اليمين لليسار (RTL) للغة العربية في جميع عناصر التطبيق
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SaqrMainScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun SaqrMainScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Dashboard, 1: Chat, 2: Models, 3: Security Bridge

    val ramUsage by viewModel.ramUsage.collectAsState()
    val latency by viewModel.latency.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val battery by viewModel.battery.collectAsState()
    val aiStatus by viewModel.aiStatus.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val models by viewModel.models.collectAsState()
    val hasSecurePerm by viewModel.hasSecurePermission.collectAsState()
    val hasRoot by viewModel.hasRootAccess.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CyberBg,
        topBar = {
            SaqrHeader(aiStatus = aiStatus, hasRoot = hasRoot)
        },
        bottomBar = {
            SaqrBottomNavBar(selectedTab = selectedTab, onTabSelect = { selectedTab = it })
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(CyberBgGradientStart, CyberBg, CyberBgGradientEnd)
                    )
                )
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(200))
                },
                label = "TabTransition"
            ) { tabIndex ->
                when (tabIndex) {
                    0 -> DashboardTabContent(
                        ramUsage = ramUsage,
                        latency = latency,
                        temperature = temperature,
                        battery = battery,
                        aiStatus = aiStatus,
                        isProcessing = isProcessing,
                        activeModelName = models.find { it.isActive }?.name ?: "Phi-3.5-mini",
                        lastAiMessage = messages.lastOrNull { !it.isUser }?.text ?: "في الانتظار...",
                        onQuickCommand = { viewModel.quickActionToggle(it) }
                    )
                    1 -> SmartChatTabContent(
                        messages = messages,
                        isProcessing = isProcessing,
                        onSendMessage = { viewModel.sendUserCommand(it) }
                    )
                    2 -> ModelsAndDownloadsTabContent(
                        models = models,
                        onDownload = { viewModel.downloadModel(it) },
                        onSwitch = { viewModel.switchActiveModel(it) }
                    )
                    3 -> SecurityAndBridgeTabContent(
                        hasSecurePerm = hasSecurePerm,
                        hasRoot = hasRoot,
                        onRefresh = { viewModel.refreshSystemStatus() }
                    )
                }
            }
        }
    }
}

@Composable
fun SaqrHeader(aiStatus: String, hasRoot: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "Alpha"
    )

    Surface(
        color = Color(0xCC0A0A0A),
        tonalElevation = 8.dp,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SYSTEM CORE v2.4.0 • OFFLINE AI",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "صقر SAQR AI",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = if (hasRoot) "مساعد ذكي متقدم [Root Supercharged]" else "مساعد ذكي متقدم [Tasker & Shizuku Ready]",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = CyberTextMuted
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (aiStatus.contains("نشط") || aiStatus.contains("جاهز")) CyberCyan.copy(alpha = alpha) else CyberPink.copy(alpha = alpha))
                        .shadow(8.dp, CircleShape, spotColor = CyberCyan)
                )
                Text(
                    text = "KERNEL_ACTIVE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SaqrBottomNavBar(selectedTab: Int, onTabSelect: (Int) -> Unit) {
    val tabs = listOf("لوحة التحكم", "الدردشة الذكية", "نماذج الذكاء", "الأمان والصلاحيات")
    val icons = listOf(Icons.Default.Dashboard, Icons.Default.Chat, Icons.Default.Memory, Icons.Default.Security)

    NavigationBar(
        containerColor = Color(0xFFA141414),
        contentColor = CyberCyan,
        tonalElevation = 12.dp
    ) {
        tabs.forEachIndexed { index, title ->
            val isSelected = selectedTab == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelect(index) },
                icon = {
                    Icon(
                        imageVector = icons[index],
                        contentDescription = title,
                        tint = if (isSelected) CyberCyan else CyberTextMuted
                    )
                },
                label = {
                    Text(
                        text = title,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CyberCyan else CyberTextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = CyberCyanDim
                )
            )
        }
    }
}

// ==================== TAB 0: DASHBOARD ====================
@Composable
fun DashboardTabContent(
    ramUsage: Float,
    latency: Int,
    temperature: Int,
    battery: Int,
    aiStatus: String,
    isProcessing: Boolean,
    activeModelName: String,
    lastAiMessage: String,
    onQuickCommand: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 4 Stat Cards Grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(modifier = Modifier.weight(1f), label = "استخدام الذاكرة", value = String.format("%.1f", ramUsage), unit = "GB", icon = Icons.Default.Memory)
            StatCard(modifier = Modifier.weight(1f), label = "سرعة الاستجابة", value = "$latency", unit = "ms", icon = Icons.Default.Speed)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(modifier = Modifier.weight(1f), label = "درجة الحرارة", value = "$temperature", unit = "°C", icon = Icons.Default.Thermostat)
            StatCard(modifier = Modifier.weight(1f), label = "طاقة البطارية", value = "$battery", unit = "%", icon = Icons.Default.BatteryChargingFull)
        }

        // Quick Direct Hardware Control Panel
        Text(
            text = "⚡ التحكم السريع في عتاد الهاتف (Direct Bridge)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = CyberCyan
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickHardwareButton(modifier = Modifier.weight(1f), title = "تشغيل Wi-Fi", icon = Icons.Default.Wifi, onClick = { onQuickCommand("تشغيل الواي فاي") })
            QuickHardwareButton(modifier = Modifier.weight(1f), title = "إيقاف Wi-Fi", icon = Icons.Default.WifiOff, color = CyberPink, onClick = { onQuickCommand("إيقاف الواي فاي") })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickHardwareButton(modifier = Modifier.weight(1f), title = "تشغيل البلوتوث", icon = Icons.Default.Bluetooth, onClick = { onQuickCommand("تشغيل البلوتوث") })
            QuickHardwareButton(modifier = Modifier.weight(1f), title = "إيقاف البلوتوث", icon = Icons.Default.BluetoothDisabled, color = CyberPink, onClick = { onQuickCommand("إيقاف البلوتوث") })
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickHardwareButton(modifier = Modifier.weight(1f), title = "تفعيل بيانات الهاتف", icon = Icons.Default.NetworkCell, onClick = { onQuickCommand("تشغيل بيانات الهاتف") })
            QuickHardwareButton(modifier = Modifier.weight(1f), title = "الوضع الليلي ON", icon = Icons.Default.DarkMode, onClick = { onQuickCommand("تفعيل الوضع الليلي") })
        }

        // SaqrAiCore Engine Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberCard),
            border = BorderStroke(1.dp, if (isProcessing) CyberPink else CyberCyan),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(
                            text = "محرك SaqrAiCore المحلي",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Text(
                            text = "$activeModelName • محرك استدلال محلي 4-bit",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = CyberTextMuted
                        )
                    }
                    Surface(
                        color = if (isProcessing) CyberPinkDim else CyberCyanDim,
                        border = BorderStroke(1.dp, if (isProcessing) CyberPink else CyberCyan),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = aiStatus,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isProcessing) CyberPink else CyberCyan
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x66000000))
                        .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("●", color = CyberGreen, fontSize = 10.sp)
                        Text("تحليل السياق: [محسّن طاقة واجهة Redmi 14C نشط • Dispatchers.IO Safe]", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFCCCCCC))
                    }
                }

                Text("آخر استجابة من المحرك:", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = CyberTextMuted)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0A0A0A))
                        .border(1.dp, Color(0xFF1A1A1A), RoundedCornerShape(10.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = lastAiMessage,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        color = Color.White,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(modifier: Modifier = Modifier, label: String, value: String, unit: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = BorderStroke(1.dp, CyberCyanDim),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = icon, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                Text(text = label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = CyberTextMuted)
            }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(text = value, fontFamily = FontFamily.Monospace, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                Text(text = unit, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF888888), modifier = Modifier.padding(bottom = 2.dp))
            }
        }
    }
}

@Composable
fun QuickHardwareButton(modifier: Modifier = Modifier, title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color = CyberCyan, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color.copy(alpha = 0.15f), contentColor = color),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(title, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ==================== TAB 1: SMART CHAT ====================
@Composable
fun SmartChatTabContent(
    messages: List<ChatMessage>,
    isProcessing: Boolean,
    onSendMessage: (String) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Chat list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatBubbleItem(message = msg)
            }
            if (isProcessing) {
                item {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyberCyan, strokeWidth = 2.dp)
                        Text("صقر AI يعالج الأمر عبر أتمتة النظام...", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = CyberCyan)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Sleek Input Area
        Surface(
            color = Color(0xFFA141414),
            border = BorderStroke(1.dp, CyberCyanDim),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("اكتب رسالتك أو أمرك للهاتف...", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = CyberTextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color(0xFF1E1E2E),
                        unfocusedContainerColor = Color(0xFF1A1A2A)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (inputText.isNotBlank()) {
                            onSendMessage(inputText)
                            inputText = ""
                        }
                    }),
                    singleLine = true
                )

                // Voice Simulation Button
                IconButton(
                    onClick = {
                        Toast.makeText(context, "🎤 جاري الاستماع للأمر الصوتي عبر ميكروفون الهاتف...", Toast.LENGTH_SHORT).show()
                        onSendMessage("تشغيل الواي فاي والبلوتوث")
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .background(CyberPink, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "صوت", tint = Color.White)
                }

                // Send Button
                Button(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onSendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier.height(44.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إرسال", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ChatBubbleItem(message: ChatMessage) {
    val align = if (message.isUser) Alignment.CenterStart else Alignment.CenterEnd
    val bg = if (message.isUser) Brush.linearGradient(listOf(CyberCyan, CyberBlue)) else Brush.linearGradient(listOf(Color(0xFF1A1A2E), Color(0xFF16213E)))
    val textColor = if (message.isUser) Color.Black else Color.White

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = if (message.isUser) Alignment.Start else Alignment.End) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.82f)
                .clip(RoundedCornerShape(14.dp))
                .background(bg)
                .border(1.dp, if (message.isUser) CyberCyan else CyberCyanDim, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (message.isUser) "أنت (المستخدم)" else "صقر AI (الوكيل المدمج)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (message.isUser) Color(0xFF003344) else CyberCyan
                    )
                    Text(text = message.timestamp, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = if (message.isUser) Color(0xFF003344) else CyberTextMuted)
                }
                Text(
                    text = message.text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = textColor,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// ==================== TAB 2: AI MODELS & DOWNLOADS ====================
@Composable
fun ModelsAndDownloadsTabContent(
    models: List<AiModel>,
    onDownload: (String) -> Unit,
    onSwitch: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "📦 مستودع النماذج المحلية والتنزيلات (Offline GGUF / ONNX)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White
        )
        Text(
            text = "شخصية وكيل الذكاء المدمجة في الـ APK تعمل بأقصى سرعة مع أي نموذج تقوم بتحديده أدناه:",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = CyberTextMuted
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(models, key = { it.id }) { model ->
                AiModelListItem(model = model, onDownload = { onDownload(model.id) }, onSwitch = { onSwitch(model.id) })
            }
        }
    }
}

@Composable
fun AiModelListItem(model: AiModel, onDownload: () -> Unit, onSwitch: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (model.isActive) Color(0xFF1E2A4A) else CyberCard),
        border = BorderStroke(1.dp, if (model.isActive) CyberCyan else CyberCyanDim),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(
                        imageVector = if (model.isActive) Icons.Default.Bolt else Icons.Default.SmartToy,
                        contentDescription = null,
                        tint = if (model.isActive) CyberCyan else CyberTextMuted,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(model.name, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Text(model.subtitle, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = CyberTextMuted)
                    }
                }

                if (model.isActive) {
                    Surface(color = CyberCyan.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp), border = BorderStroke(1.dp, CyberCyan)) {
                        Text("النموذج النشط ✔", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("الحجم التقديري: ${model.sizeGb} GB", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = CyberCyan)

                if (model.isDownloading) {
                    Column(modifier = Modifier.fillMaxWidth(0.5f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        LinearProgressIndicator(progress = { model.downloadProgress }, modifier = Modifier.fillMaxWidth(), color = CyberCyan, trackColor = CyberSurface)
                        Text("${(model.downloadProgress * 100).toInt()}% جاري التنزيل...", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = CyberCyan)
                    }
                } else if (!model.isDownloaded) {
                    Button(
                        onClick = onDownload,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("تنزيل النموذج", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (!model.isActive) {
                    OutlinedButton(
                        onClick = onSwitch,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                        border = BorderStroke(1.dp, CyberCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("تبديل لهذا النموذج", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==================== TAB 3: SECURITY BRIDGE ====================
@Composable
fun SecurityAndBridgeTabContent(
    hasSecurePerm: Boolean,
    hasRoot: Boolean,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "🛡️ خزنة الصلاحيات وجسر التحكم المباشر (Security Bridge)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White
        )
        Text(
            text = "يتطلب أندرويد 10+ صلاحية WRITE_SECURE_SETTINGS أو توفر الروت لتعديل الواي فاي والبيانات دون تجميد الواجهة:",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = CyberTextMuted
        )

        // Vault item 1: WRITE_SECURE_SETTINGS status
        VaultItemCard(
            title = "صلاحية WRITE_SECURE_SETTINGS",
            statusText = if (hasSecurePerm) "الصلاحية ممنوحة بنجاح برمجياً ✔" else "غير ممنوحة • يرجى تطبيق أمر الـ ADB أدناه",
            isOk = hasSecurePerm,
            icon = Icons.Default.GppGood
        )

        // Vault item 2: Root / Shizuku check
        VaultItemCard(
            title = "صلاحيات الروت (Root Access su)",
            statusText = if (hasRoot) "تم اكتشاف صلاحيات الروت بنجاح 🚀 (أقصى أداء)" else "الروت غير مفعّل • يتم استخدام Tasker Intent Broadcast كبديل",
            isOk = hasRoot,
            icon = Icons.Default.AdminPanelSettings
        )

        // Vault item 3: Tasker integration
        VaultItemCard(
            title = "خدمة ربط TaskerIntegrationService",
            statusText = "متصل بنجاح عبر Intent Broadcast (Dispatchers.IO Safe)",
            isOk = true,
            icon = Icons.Default.LeakAdd
        )

        // ADB Advice Box
        Text(
            text = "💡 نصيحة المطور لتفعيل تحكم النظام الشامل عبر ADB Shell:",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = CyberPink
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF12121E)),
            border = BorderStroke(1.dp, CyberPink.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = SystemSettingsManager.ADB_GRANT_ADVICE,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = CyberCyan,
                    lineHeight = 16.sp
                )

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("adb_command", SystemSettingsManager.ADB_GRANT_ADVICE)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "✔ تم نسخ الأمر للحافظة! قم بلصقه في حاسوبك أو ترمينال Shizuku", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPink.copy(alpha = 0.25f), contentColor = CyberPink),
                    border = BorderStroke(1.dp, CyberPink),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("نسخ أمر الـ ADB", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Button(
            onClick = onRefresh,
            modifier = Modifier.fillMaxWidth().height(46.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CyberSurface, contentColor = CyberCyan),
            border = BorderStroke(1.dp, CyberCyan),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("إعادة فحص حالة الصلاحيات والنظام", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun VaultItemCard(title: String, statusText: String, isOk: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = BorderStroke(1.dp, if (isOk) CyberCyanDim else CyberPinkDim),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, contentDescription = null, tint = if (isOk) CyberGreen else CyberPink, modifier = Modifier.size(28.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                Text(statusText, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = if (isOk) CyberTextMuted else CyberPink)
            }
        }
    }
}
