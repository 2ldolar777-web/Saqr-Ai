package com.example.engine

import android.content.Context
import com.example.manager.SettingsResult
import com.example.manager.SystemSettingsManager
import com.example.service.TaskerIntegrationService
import java.util.Locale

class TaskEngine(private val context: Context) {

    private val settingsManager = SystemSettingsManager(context)
    private val taskerService = TaskerIntegrationService(context)

    data class ExecutionReport(
        val originalCommand: String,
        val actionDescription: String,
        val resultText: String,
        val isSuccess: Boolean,
        val redirectedToTasker: Boolean = false,
        val adviceText: String? = null
    )

    /**
     * الدالة المركزية لتحليل أوامر المستخدم الصوتية أو النصية وتنفيذها بذكاء
     */
    fun analyzeAndExecuteComplexCommands(command: String): ExecutionReport {
        val lower = command.lowercase(Locale.getDefault())
        val cleanArabic = command.trim()

        val isEnable = lower.contains("on") || lower.contains("enable") || cleanArabic.contains("تشغيل") || cleanArabic.contains("شغل") || cleanArabic.contains("تفعيل")
        val isDisable = lower.contains("off") || lower.contains("disable") || cleanArabic.contains("إيقاف") || cleanArabic.contains("اطف") || cleanArabic.contains("تعطيل")

        // 1. الواي فاي (Wi-Fi)
        if (lower.contains("wifi") || lower.contains("wi-fi") || cleanArabic.contains("واي فاي") || cleanArabic.contains("النت")) {
            val targetState = if (isDisable) false else isEnable
            val result = settingsManager.toggleWifi(targetState)
            return handleSettingsResult("التحكم في الواي فاي", targetState, result, "WIFI_TOGGLE")
        }

        // 2. البلوتوث (Bluetooth)
        if (lower.contains("bluetooth") || cleanArabic.contains("بلوتوث")) {
            val targetState = if (isDisable) false else isEnable
            val result = settingsManager.toggleBluetooth(targetState)
            return handleSettingsResult("التحكم في البلوتوث", targetState, result, "BLUETOOTH_TOGGLE")
        }

        // 3. بيانات الهاتف (Mobile Data)
        if (lower.contains("data") || cleanArabic.contains("بيانات") || cleanArabic.contains("الداتا")) {
            val targetState = if (isDisable) false else isEnable
            val result = settingsManager.toggleMobileData(targetState)
            return handleSettingsResult("التحكم في بيانات الهاتف", targetState, result, "MOBILE_DATA_TOGGLE")
        }

        // 4. الوضع الليلي (Dark Mode / Night)
        if (lower.contains("dark") || lower.contains("night") || cleanArabic.contains("ليلي") || cleanArabic.contains("مظلم")) {
            val valInt = if (isDisable) 1 else 2 // ui_night_mode: 1=no, 2=yes
            val res = settingsManager.modifySecureSetting("ui_night_mode", valInt)
            return handleSettingsResult("تبديل مظهر النظام", !isDisable, res, "NIGHT_MODE_TASK")
        }

        // 5. أوامر مخصصة أو معقدة يتم تمريرها مباشرة لـ Tasker
        val broadcastSent = taskerService.sendAutomationTask(command, "SAQR_AI_AUTO")
        return ExecutionReport(
            originalCommand = command,
            actionDescription = "توجيه أمر أتمتة مخصص لـ Tasker",
            resultText = if (broadcastSent) "تم توجيه الأمر '$command' تلقائياً إلى محرك Tasker بنجاح" else "فشل الاتصال بخدمة Tasker في النظام",
            isSuccess = broadcastSent,
            redirectedToTasker = true
        )
    }

    private fun handleSettingsResult(
        featureName: String,
        enable: Boolean,
        result: SettingsResult,
        taskerFallbackTask: String
    ): ExecutionReport {
        val stateText = if (enable) "تشغيل" else "إيقاف"
        return when (result) {
            is SettingsResult.Success -> ExecutionReport(
                originalCommand = "$featureName ($stateText)",
                actionDescription = featureName,
                resultText = "${result.message} عبر [${result.methodUsed}]",
                isSuccess = true
            )
            is SettingsResult.RequiresExternalAutomation -> {
                // التوجيه التلقائي لـ Tasker
                val sent = taskerService.sendAutomationTask(taskerFallbackTask, if (enable) "1" else "0")
                ExecutionReport(
                    originalCommand = "$featureName ($stateText)",
                    actionDescription = "$featureName (عبر Tasker Bridge)",
                    resultText = "قيود النظام منعت التحكم المباشر. تم تحويل البث تلقائياً لـ Tasker: ${if (sent) "نجاح الإرسال" else "فشل البث"}",
                    isSuccess = sent,
                    redirectedToTasker = true,
                    adviceText = result.reason
                )
            }
            is SettingsResult.PermissionDenied -> ExecutionReport(
                originalCommand = "$featureName ($stateText)",
                actionDescription = featureName,
                resultText = "تنبيه: الصلاحية المطلوبة [${result.permission}] غير ممنوحة للجهاز.",
                isSuccess = false,
                adviceText = result.adbCommandAdvice
            )
            is SettingsResult.Error -> ExecutionReport(
                originalCommand = "$featureName ($stateText)",
                actionDescription = featureName,
                resultText = "خطأ في أتمتة الإعداد: ${result.exception}",
                isSuccess = false
            )
        }
    }
}
