package com.example.manager

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.InputStreamReader

sealed class SettingsResult {
    data class Success(val message: String, val methodUsed: String) : SettingsResult()
    data class PermissionDenied(
        val permission: String,
        val adbCommandAdvice: String
    ) : SettingsResult()
    data class RequiresExternalAutomation(val feature: String, val reason: String) : SettingsResult()
    data class Error(val exception: String) : SettingsResult()
}

class SystemSettingsManager(private val context: Context) {

    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val bluetoothManager = context.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    companion object {
        const val ADB_GRANT_ADVICE = "adb shell pm grant com.aistudio.saqrai.kxmpzq android.permission.WRITE_SECURE_SETTINGS"
        const val TAG = "SystemSettingsManager"
    }

    /**
     * التحقق من صلاحية WRITE_SECURE_SETTINGS برمجياً قبل محاولة تعديل النظام
     */
    fun hasWriteSecureSettingsPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_SECURE_SETTINGS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * فحص توفر صلاحيات الروت (Root / Superuser) في هذا الهاتف
     */
    fun isRootAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readLine()
            process.waitFor()
            output != null && output.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    /**
     * تنفيذ أمر نظام بأقصى صلاحيات متاحة (Root su أو ADB Shell / Shizuku)
     */
    fun executeRootOrShellCommand(command: String): Boolean {
        // محاولة عبر الروت أولاً
        try {
            val suProcess = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val exitCode = suProcess.waitFor()
            if (exitCode == 0) {
                Log.d(TAG, "تم تنفيذ الأمر عبر الروت بنجاح: $command")
                return true
            }
        } catch (e: Exception) {
            Log.w(TAG, "الروت غير متوفر، التبديل إلى أمر Shell مباشر: ${e.message}")
        }

        // محاولة عبر Shizuku / ADB Shell العادي
        return try {
            val shProcess = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val exitCode = shProcess.waitFor()
            Log.d(TAG, "تنفيذ Shell مباشر ينتهي بالكود $exitCode للأمر: $command")
            exitCode == 0
        } catch (e: Exception) {
            Log.e(TAG, "فشل تنفيذ Shell: ${e.localizedMessage}")
            false
        }
    }

    /**
     * التحكم الكامل في الواي فاي (Wi-Fi) المباشر أو عبر أوامر الروت/Shizuku
     */
    @Suppress("DEPRECATION")
    fun toggleWifi(enable: Boolean): SettingsResult {
        try {
            // 1. المحاولة المباشرة التقليدية
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                wifiManager?.setWifiEnabled(enable)
                return SettingsResult.Success("تم ${if (enable) "تشغيل" else "إيقاف"} الواي فاي برمجياً مباشرة", "WifiManager API")
            }

            // 2. في Android 10+ نستخدم Root / Shell svc wifi
            val shellCmd = if (enable) "svc wifi enable" else "svc wifi disable"
            if (executeRootOrShellCommand(shellCmd)) {
                return SettingsResult.Success("تم ${if (enable) "تشغيل" else "إيقاف"} الواي فاي عبر أوامر النظام المتقدمة", "Root / Shizuku Shell")
            }

            // 3. التحقق من صلاحية WRITE_SECURE_SETTINGS
            if (!hasWriteSecureSettingsPermission()) {
                return SettingsResult.PermissionDenied(
                    permission = Manifest.permission.WRITE_SECURE_SETTINGS,
                    adbCommandAdvice = ADB_GRANT_ADVICE
                )
            }

            // 4. التوجيه إلى أتمتة Tasker الخارجية إذا منعت قيود أندرويد الصارمة
            return SettingsResult.RequiresExternalAutomation(
                feature = "Wi-Fi (${if (enable) "تشغيل" else "إيقاف"})",
                reason = "قيود أندرويد 10+ تمنع التطبيقات غير النظامية، تم التوجيه للبث الخارجي"
            )
        } catch (e: SecurityException) {
            return SettingsResult.PermissionDenied(
                permission = Manifest.permission.CHANGE_WIFI_STATE,
                adbCommandAdvice = ADB_GRANT_ADVICE
            )
        } catch (e: Exception) {
            return SettingsResult.Error("خطأ غير متوقع في الواي فاي: ${e.localizedMessage}")
        }
    }

    /**
     * التحكم في البلوتوث مباشرة أو عبر الروت
     */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun toggleBluetooth(enable: Boolean): SettingsResult {
        try {
            if (bluetoothAdapter == null) {
                return SettingsResult.Error("محول البلوتوث غير متوفر في هذا الجهاز")
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return SettingsResult.PermissionDenied(
                        permission = Manifest.permission.BLUETOOTH_CONNECT,
                        adbCommandAdvice = "قم بمنح صلاحيات البلوتوث من إعدادات التطبيق"
                    )
                }
            }

            val directSuccess = if (enable) bluetoothAdapter.enable() else bluetoothAdapter.disable()
            if (directSuccess) {
                return SettingsResult.Success("تم ${if (enable) "تشغيل" else "إيقاف"} البلوتوث مباشرة", "BluetoothAdapter Direct")
            }

            // المحاولة عبر Shell المتقدم (Root / Shizuku)
            val btCmd = if (enable) "cmd bluetooth_manager enable" else "cmd bluetooth_manager disable"
            if (executeRootOrShellCommand(btCmd)) {
                return SettingsResult.Success("تم ${if (enable) "تشغيل" else "إيقاف"} البلوتوث عبر Root/Shell", "Root / Shizuku Shell")
            }

            return SettingsResult.RequiresExternalAutomation(
                feature = "Bluetooth (${if (enable) "تشغيل" else "إيقاف"})",
                reason = "تحديثات أندرويد الصارمة تتطلب تطبيق أتمتة مخصص (Tasker)"
            )
        } catch (e: SecurityException) {
            return SettingsResult.PermissionDenied(
                permission = "BLUETOOTH_ADMIN",
                adbCommandAdvice = ADB_GRANT_ADVICE
            )
        } catch (e: Exception) {
            return SettingsResult.Error("خطأ أثناء تحكم البلوتوث: ${e.localizedMessage}")
        }
    }

    /**
     * التحكم في بيانات الهاتف (Mobile Data) - يتطلب Root أو Tasker في جميع إصدارات أندرويد الحديثة
     */
    fun toggleMobileData(enable: Boolean): SettingsResult {
        val dataCmd = if (enable) "svc data enable" else "svc data disable"
        if (executeRootOrShellCommand(dataCmd)) {
            return SettingsResult.Success("تم ${if (enable) "تشغيل" else "إيقاف"} بيانات الهاتف عبر Root/Shizuku", "Root / Shizuku Command")
        }

        if (!hasWriteSecureSettingsPermission()) {
            return SettingsResult.PermissionDenied(
                permission = Manifest.permission.WRITE_SECURE_SETTINGS,
                adbCommandAdvice = ADB_GRANT_ADVICE
            )
        }

        return SettingsResult.RequiresExternalAutomation(
            feature = "Mobile Data (${if (enable) "تشغيل" else "إيقاف"})",
            reason = "بيانات الهاتف محمية بإحكام في أندرويد، يتم توجيهها فوراً لـ Tasker Broadcast"
        )
    }

    /**
     * تعديل الإعدادات الحساسة عبر Settings.Global أو Settings.Secure
     */
    fun modifySecureSetting(settingKey: String, value: Int): SettingsResult {
        if (!hasWriteSecureSettingsPermission()) {
            return SettingsResult.PermissionDenied(
                permission = Manifest.permission.WRITE_SECURE_SETTINGS,
                adbCommandAdvice = ADB_GRANT_ADVICE
            )
        }
        return try {
            val result = Settings.Global.putInt(context.contentResolver, settingKey, value)
            if (result) {
                SettingsResult.Success("تم تحديث إعداد $settingKey إلى $value", "Settings.Global")
            } else {
                SettingsResult.Error("فشل حفظ الإعداد في سجل النظام Global")
            }
        } catch (e: SecurityException) {
            SettingsResult.PermissionDenied(
                permission = Manifest.permission.WRITE_SECURE_SETTINGS,
                adbCommandAdvice = ADB_GRANT_ADVICE
            )
        } catch (e: Exception) {
            SettingsResult.Error("خطأ في كتابة الإعداد: ${e.localizedMessage}")
        }
    }
}

